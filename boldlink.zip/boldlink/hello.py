def Hello():
    print("Hello World!")
    name = input("Enter your name:")
    print("Hello", name)
    input("Press enter to close program")
    
    
Hello()
    
